1)	Create dB name atiweb (as Green Circu)
2)	And click atiweb and click import and click choose file and select 127_0_0_1 and click go
3)	And copy assignmentHNDIT2021F49     on    C:\xampp\htdocs 
4)	Please do unzip files, before all above doing.
